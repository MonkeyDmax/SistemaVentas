import csv
from pathlib import Path
from datetime import datetime
class GestorVentas:
    CAMPOS=["id_venta","fecha","id_producto","nombre_producto","cantidad","precio_compra_unitario","precio_unitario","total_venta","utilidad"]
    def __init__(self,inventario,ruta): self.inventario=inventario; self.ruta=Path(ruta); self._crear()
    def _crear(self):
        if not self.ruta.exists():
            with self.ruta.open("w",newline="",encoding="utf-8-sig") as f: csv.DictWriter(f,fieldnames=self.CAMPOS).writeheader()
    def _id(self):
        with self.ruta.open(encoding="utf-8-sig") as f: return max([int(x["id_venta"]) for x in csv.DictReader(f) if x.get("id_venta")],default=0)+1
    def registrar_venta(self,i,c):
        p=self.inventario.buscar_por_id(i)
        if not p: raise ValueError("Producto no encontrado.")
        p.reducir_stock(c); total=round(c*p.precio_venta,2); utilidad=round(c*(p.precio_venta-p.precio_compra),2)
        v={"id_venta":self._id(),"fecha":datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"id_producto":p.id_producto,"nombre_producto":p.nombre,"cantidad":c,"precio_compra_unitario":f"{p.precio_compra:.2f}","precio_unitario":f"{p.precio_venta:.2f}","total_venta":f"{total:.2f}","utilidad":f"{utilidad:.2f}"}
        with self.ruta.open("a",newline="",encoding="utf-8-sig") as f: csv.DictWriter(f,fieldnames=self.CAMPOS).writerow(v)
        self.inventario.guardar(); return v
