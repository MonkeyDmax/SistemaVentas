import os,csv
from pathlib import Path
import customtkinter as ctk
from tkinter import ttk,messagebox
from inventario import Inventario
from ventas import GestorVentas
BASE=Path(__file__).resolve().parent
ctk.set_appearance_mode("System"); ctk.set_default_color_theme("blue")
class App(ctk.CTk):
 def __init__(self):
  super().__init__(); self.title("Sistema de Inventario y Ventas"); self.geometry("1180x720"); self.minsize(980,620)
  self.inv=Inventario(BASE/"productos.csv"); self.ventas=GestorVentas(self.inv,BASE/"ventas.csv")
  self.grid_columnconfigure(1,weight=1); self.grid_rowconfigure(0,weight=1); self.sidebar(); self.area=ctk.CTkFrame(self,corner_radius=0); self.area.grid(row=0,column=1,sticky="nsew"); self.dashboard()
 def sidebar(self):
  s=ctk.CTkFrame(self,width=245,corner_radius=0,fg_color="#17365D"); s.grid(row=0,column=0,sticky="nsew"); s.grid_propagate(False)
  ctk.CTkLabel(s,text="INVENTARIO\nY VENTAS",font=("Segoe UI",23,"bold"),text_color="white").pack(pady=(38,30))
  for t,c in [("Dashboard",self.dashboard),("Inventario",self.inventario),("Agregar producto",self.agregar),("Reabastecer",self.reabastecer),("Registrar venta",self.vender),("Reportes",self.reportes)]: ctk.CTkButton(s,text=t,command=c,anchor="w",height=43,fg_color="transparent",hover_color="#2F5597").pack(fill="x",padx=18,pady=4)
  ctk.CTkOptionMenu(s,values=["System","Light","Dark"],command=ctk.set_appearance_mode).pack(side="bottom",pady=25)
 def page(self,title,sub=""):
  for w in self.area.winfo_children(): w.destroy()
  self.area.grid_columnconfigure(0,weight=1); self.area.grid_rowconfigure(1,weight=1)
  h=ctk.CTkFrame(self.area,fg_color="transparent"); h.grid(row=0,column=0,sticky="ew",padx=28,pady=(24,10)); ctk.CTkLabel(h,text=title,font=("Segoe UI",28,"bold")).pack(anchor="w"); ctk.CTkLabel(h,text=sub,text_color="gray").pack(anchor="w")
  b=ctk.CTkFrame(self.area,fg_color="transparent"); b.grid(row=1,column=0,sticky="nsew",padx=28,pady=(5,25)); b.grid_columnconfigure(0,weight=1); b.grid_rowconfigure(1,weight=1); return b
 def datos(self):
  with (BASE/"ventas.csv").open(encoding="utf-8-sig") as f: vs=list(csv.DictReader(f))
  return vs,sum(float(v["total_venta"]) for v in vs),sum(float(v["utilidad"]) for v in vs)
 def card(self,m,col,t,v,color):
  m.grid_columnconfigure(col,weight=1); f=ctk.CTkFrame(m,corner_radius=14); f.grid(row=0,column=col,sticky="ew",padx=7); ctk.CTkLabel(f,text=t,text_color="gray").pack(anchor="w",padx=18,pady=(15,2)); ctk.CTkLabel(f,text=v,text_color=color,font=("Segoe UI",25,"bold")).pack(anchor="w",padx=18,pady=(0,17))
 def dashboard(self):
  b=self.page("Dashboard","Resumen general del negocio"); vs,ing,uti=self.datos(); c=ctk.CTkFrame(b,fg_color="transparent"); c.grid(row=0,column=0,sticky="ew")
  self.card(c,0,"Productos",str(len(self.inv.productos)),"#2563EB"); self.card(c,1,"Unidades",str(sum(p.stock for p in self.inv.productos)),"#0891B2"); self.card(c,2,"Ingresos",f"${ing:,.2f}","#16A34A"); self.card(c,3,"Utilidad",f"${uti:,.2f}","#D97706")
  f=ctk.CTkFrame(b,corner_radius=14); f.grid(row=1,column=0,sticky="nsew",pady=(18,0)); ctk.CTkLabel(f,text="Productos con menor existencia",font=("Segoe UI",18,"bold")).pack(anchor="w",padx=20,pady=18)
  for p in sorted(self.inv.productos,key=lambda x:x.stock)[:6]: ctk.CTkLabel(f,text=f"{p.nombre}: {p.stock} unidades").pack(anchor="w",padx=25,pady=5)
 def inventario(self):
  b=self.page("Inventario","Existencias y precios actuales"); f=ctk.CTkFrame(b); f.grid(row=0,column=0,sticky="nsew"); b.grid_rowconfigure(0,weight=1); f.grid_rowconfigure(0,weight=1); f.grid_columnconfigure(0,weight=1)
  cols=("id","producto","categoria","compra","venta","stock"); t=ttk.Treeview(f,columns=cols,show="headings")
  for c,n in zip(cols,["ID","Producto","Categoría","Compra","Venta","Stock"]): t.heading(c,text=n); t.column(c,anchor="center")
  t.grid(row=0,column=0,sticky="nsew",padx=15,pady=15)
  for p in self.inv.productos:t.insert("","end",values=(p.id_producto,p.nombre,p.categoria,f"${p.precio_compra:.2f}",f"${p.precio_venta:.2f}",p.stock))
 def form(self,title,sub,fields,button,action,combo=None):
  b=self.page(title,sub); f=ctk.CTkFrame(b,corner_radius=14); f.grid(row=0,column=0,sticky="n",padx=20,pady=10); entries=[]; r=0
  if combo:
   ctk.CTkLabel(f,text="Producto",font=("Segoe UI",13,"bold")).grid(row=r,column=0,sticky="w",padx=24,pady=(20,5)); cb=ctk.CTkComboBox(f,values=combo,width=390); cb.grid(row=r+1,column=0,padx=24,pady=(0,8)); entries.append(cb); r+=2
  for label in fields:
   ctk.CTkLabel(f,text=label,font=("Segoe UI",13,"bold")).grid(row=r,column=0,sticky="w",padx=24,pady=(10,5)); e=ctk.CTkEntry(f,width=390,height=38); e.grid(row=r+1,column=0,padx=24,pady=(0,5)); entries.append(e); r+=2
  ctk.CTkButton(f,text=button,height=42,command=lambda:action(entries)).grid(row=r,column=0,sticky="ew",padx=24,pady=22)
 def agregar(self):
  def go(e):
   try:self.inv.agregar_producto(e[0].get(),e[1].get(),float(e[2].get().replace(',','.')),float(e[3].get().replace(',','.')),int(e[4].get())); messagebox.showinfo("Correcto","Producto guardado."); self.inventario()
   except ValueError as x:messagebox.showerror("Error",str(x))
  self.form("Agregar producto","Registra un nuevo artículo",["Nombre","Categoría","Precio de compra","Precio de venta","Stock inicial"],"Guardar producto",go)
 def reabastecer(self):
  vals=[f"{p.id_producto} - {p.nombre}" for p in self.inv.productos]
  def go(e):
   try:self.inv.reabastecer(int(e[0].get().split(" - ")[0]),int(e[1].get())); messagebox.showinfo("Correcto","Stock actualizado."); self.inventario()
   except ValueError as x:messagebox.showerror("Error",str(x))
  self.form("Reabastecer","Aumenta existencias",["Cantidad"],"Actualizar stock",go,vals)
 def vender(self):
  vals=[f"{p.id_producto} - {p.nombre} (stock: {p.stock})" for p in self.inv.productos]
  def go(e):
   try:v=self.ventas.registrar_venta(int(e[0].get().split(" - ")[0]),int(e[1].get())); messagebox.showinfo("Venta registrada",f"Folio: {v['id_venta']}\nTotal: ${v['total_venta']}"); self.dashboard()
   except ValueError as x:messagebox.showerror("Error",str(x))
  self.form("Registrar venta","Selecciona producto y cantidad",["Cantidad vendida"],"Registrar venta",go,vals)
 def reportes(self):
  b=self.page("Reportes","Indicadores de ventas"); vs,ing,uti=self.datos(); c=ctk.CTkFrame(b,fg_color="transparent"); c.grid(row=0,column=0,sticky="ew"); self.card(c,0,"Operaciones",str(len(vs)),"#2563EB"); self.card(c,1,"Unidades vendidas",str(sum(int(v['cantidad']) for v in vs)),"#0891B2"); self.card(c,2,"Ingresos",f"${ing:,.2f}","#16A34A"); self.card(c,3,"Utilidad",f"${uti:,.2f}","#D97706")
if __name__=="__main__":App().mainloop()
