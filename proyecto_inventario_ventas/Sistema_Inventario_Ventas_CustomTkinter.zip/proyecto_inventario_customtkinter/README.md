# Sistema de Inventario y Ventas con CustomTkinter

Instalar: `python -m pip install -r requirements.txt`

Ejecutar: `python app_gui.py`

En Windows también puede abrirse `EJECUTAR_GUI.bat`.
