from dataclasses import dataclass
@dataclass
class Producto:
    id_producto:int; nombre:str; categoria:str; precio_compra:float; precio_venta:float; stock:int
    def agregar_stock(self,cantidad):
        if cantidad<=0: raise ValueError("La cantidad debe ser mayor que cero.")
        self.stock+=cantidad
    def reducir_stock(self,cantidad):
        if cantidad<=0: raise ValueError("La cantidad debe ser mayor que cero.")
        if cantidad>self.stock: raise ValueError(f"Stock insuficiente. Disponibles: {self.stock}.")
        self.stock-=cantidad
    def a_fila_csv(self):
        return {"id_producto":self.id_producto,"nombre":self.nombre,"categoria":self.categoria,"precio_compra":f"{self.precio_compra:.2f}","precio_venta":f"{self.precio_venta:.2f}","stock":self.stock}
