@echo off
python -m pip install -r requirements.txt
python app_gui.py
pause
