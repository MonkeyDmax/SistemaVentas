import csv
from pathlib import Path
from producto import Producto
class Inventario:
    CAMPOS=["id_producto","nombre","categoria","precio_compra","precio_venta","stock"]
    def __init__(self,ruta): self.ruta=Path(ruta); self.productos=[]; self._crear(); self.cargar()
    def _crear(self):
        if not self.ruta.exists():
            with self.ruta.open("w",newline="",encoding="utf-8-sig") as f: csv.DictWriter(f,fieldnames=self.CAMPOS).writeheader()
    def cargar(self):
        self.productos=[]
        with self.ruta.open(encoding="utf-8-sig") as f:
            for x in csv.DictReader(f):
                if x.get("id_producto"): self.productos.append(Producto(int(x["id_producto"]),x["nombre"],x["categoria"],float(x["precio_compra"]),float(x["precio_venta"]),int(x["stock"])))
    def guardar(self):
        with self.ruta.open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.DictWriter(f,fieldnames=self.CAMPOS); w.writeheader(); w.writerows(p.a_fila_csv() for p in self.productos)
    def buscar_por_id(self,i): return next((p for p in self.productos if p.id_producto==i),None)
    def agregar_producto(self,nombre,categoria,pc,pv,stock):
        nombre=nombre.strip()
        if not nombre: raise ValueError("El nombre es obligatorio.")
        if any(p.nombre.lower()==nombre.lower() for p in self.productos): raise ValueError("El producto ya existe.")
        if pc<0 or pv<0 or stock<0: raise ValueError("No se aceptan valores negativos.")
        if pv<pc: raise ValueError("El precio de venta debe ser mayor o igual al costo.")
        p=Producto(max([x.id_producto for x in self.productos],default=0)+1,nombre,categoria.strip() or "Otro",pc,pv,stock); self.productos.append(p); self.guardar(); return p
    def reabastecer(self,i,c):
        p=self.buscar_por_id(i)
        if not p: raise ValueError("Producto no encontrado.")
        p.agregar_stock(c); self.guardar()
